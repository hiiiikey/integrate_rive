package com.example.integrate_rive

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
