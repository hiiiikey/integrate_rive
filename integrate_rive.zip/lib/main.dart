// ignore_for_file: unused_field, unused_element

import 'package:flutter/material.dart';
import 'package:rive/rive.dart';

void main() {
  runApp(const RiveAnimation());
}

// initalize these variables cause they kept giving me errors
late bool _isPlayingLick;
late RiveAnimationController _idleController;
late RiveAnimationController _lickController;

void setState(VoidCallback callback) {
  setState(callback);
}

class RiveAnimation extends StatefulWidget {
  const RiveAnimation({super.key});

  @override
  State<RiveAnimation> createState() => _RiveAnimationState();

  static asset(String s,
      {required List<RiveAnimationController> controllers,
      required BoxFit fit}) {}
}

class _RiveAnimationState extends State<RiveAnimation> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: RiveAnimationScreen(),
    );
  }
}

class RiveAnimationScreen extends StatefulWidget {
  const RiveAnimationScreen({super.key});

  @override
  State<RiveAnimationScreen> createState() => _RiveAnimationScreenState();
}

class _RiveAnimationScreenState extends State<RiveAnimationScreen> {
  late RiveAnimationController _idleController; // Controller for idle animation
  late RiveAnimationController _lickController; // Controller for lick animation
  // ignore: prefer_final_fields
  bool _isPlayingLick = false;

  @override
  void initState() {
    super.initState();
    // Initialize the idle animation when the app starts
    _idleController = SimpleAnimation('Idle');
    _lickController = SimpleAnimation('Lick');
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw UnimplementedError();
  }
}

// Function to swithc the lick animation
void _playLickAnimation() {
  setState(() {
    _isPlayingLick = true;
  });

// Wait 5 seconds because blen said that's how long the animations take, AND RETURN TO IDLE
  Future.delayed(const Duration(seconds: 5), () {
    setState(() {
      _isPlayingLick = false;
    });
  });
}

// UI
@override
Widget build(BuildContext context) {
  return Scaffold(
    appBar: AppBar(
      title: Text('Integrating Rive Animations with Flutter'),
    ),
    body: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        SizedBox(
          height: 300,
          child: RiveAnimation.asset(
            _isPlayingLick
                ? 'assets/animation/cat_lick.riv'
                : 'assets/animation/cat_idle.riv',
            controllers: [_isPlayingLick ? _lickController : _idleController],
            fit: BoxFit.contain,
          ),
        ),

        SizedBox(height: 50),
        // Button to trigger lick animation
        ElevatedButton(
          onPressed: _isPlayingLick ? null : _playLickAnimation,
          child: Text('Lick Nose'),
        ),
      ],
    ),
  );
}
